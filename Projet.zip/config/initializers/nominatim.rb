Nominatim.configure do |config|
  config.email = 'sebastien.gadot@utbm.fr'
end